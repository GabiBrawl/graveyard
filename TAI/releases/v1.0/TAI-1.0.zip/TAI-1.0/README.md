# TAI - Transparent Account Image
Have you ever tried to apply an image with transparent background, but windows changed the transparent to black? Well, here I have the solution! Just download and run the program with administrative privileges, get the image you wanna set, apply and you're done!

## The program
![The program](https://user-images.githubusercontent.com/85069997/148305543-6afd7c03-1ba3-4f1f-8a64-41340182eac4.png)

## Before
![Without this program](https://user-images.githubusercontent.com/85069997/148305571-a18e58c1-b741-4324-b688-e75a780a075a.png)

## After
![With this program](https://user-images.githubusercontent.com/85069997/148305585-51784111-ac26-4b62-bf3e-ef00d8c1077e.png)
