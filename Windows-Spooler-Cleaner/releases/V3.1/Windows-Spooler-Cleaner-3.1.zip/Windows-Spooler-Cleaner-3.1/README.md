# Clear-Windows-Printer-Spooler

If your printer got stuck, try this program, it will clear the temporary folder where your printed files are stored.
