# BEditor
Tired of having to right click each time you wanna edit a batch file? BEditor will help you with your daily batch programming! Just run the setup, get the new file that will be created, then Drag and Drop your files over BEditor. Instant opening and easy!! :D
