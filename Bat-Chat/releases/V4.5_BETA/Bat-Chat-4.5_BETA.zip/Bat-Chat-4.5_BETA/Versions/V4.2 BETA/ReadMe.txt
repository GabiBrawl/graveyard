======================Bat-Chat V4.2======================
			  BETA


	This program only runs in Windows 7+.
	In order to use this program with multiple computers install Google Drive sync in all the computers. Configure it with the same Google account.
Then paste the "Bat-Chat" folder anywhere in your drive folder. Run the "Chat" program in the computers you want to chat. Done! (v:
	If you need something, email me at: gabrielyt219@gmail.com
	For more help/info read the Changelog file.
	[EDIT] Added the missing chat.cmd file.
