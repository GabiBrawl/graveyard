# Bat-Chat V4.2
## BETA

This is a simple Chat program between multiple computers. You need Google Drive installed in all the computers, with the same account logged in for this program to work.

If you detect any bugs, report them.


### Instructions
This program only runs in Windows 7+, as it is Windows Batch based.
In order to use this program with multiple computers install Google Drive sync in all the computers.
Then paste the "Bat-Chat" folder anywhere in your drive folder. Run the "Chat" program in the computers you want to chat.
If you need something, [![Email: gabrielyt219@gmail.com](https://img.shields.io/badge/Email-success?style=for-the-badge)](https://mail.google.com/mail/u/0/?fs=1&to=gabrielyt219@gmail.com&su=SUBJECT&body=BODY&tf=cm)
	
### Next Goals

###Automatic Update System
###Graphical interface (may take some years, if I will do it)
###New Commands
###Improved commands
###Remove the GDrive dependency

## Thanks for trying! XD
